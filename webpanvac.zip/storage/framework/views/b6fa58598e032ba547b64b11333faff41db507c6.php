<!-- Back to Top -->
<a href="#" class="btn btn-secondary btn-square rounded-circle back-to-top"><i
    class="fa fa-arrow-up text-white"></i></a>


<!-- JavaScript Libraries -->
<script src="<?php echo e(asset('frontend/ajax.googleapis.com/ajax/libs/jquery/3.6.4/jquery.min.js')); ?>"></script>
<script src="<?php echo e(asset('frontend/cdn.jsdelivr.net/npm/bootstrap%405.0.0/dist/js/bootstrap.bundle.min.js')); ?>"></script>
<script src="<?php echo e(asset('frontend/lib/wow/wow.min.js')); ?>"></script>
<script src="<?php echo e(asset('frontend/lib/easing/easing.min.js')); ?>"></script>
<script src="<?php echo e(asset('frontend/lib/waypoints/waypoints.min.js')); ?>"></script>
<script src="<?php echo e(asset('frontend/lib/owlcarousel/owl.carousel.min.js')); ?>"></script>

<!-- Template Javascript -->
<script src="<?php echo e(asset('frontend/js/main.js')); ?>"></script>
</body>


<!-- Mirrored from themewagon.github.io/HighTechIT/index.html by HTTrack Website Copier/3.x [XR&CO'2014], Mon, 06 Nov 2023 09:49:05 GMT -->

</html>
<?php /**PATH C:\wamp64\www\webari\webpanvac\resources\views/frontendlayout/footer.blade.php ENDPATH**/ ?>