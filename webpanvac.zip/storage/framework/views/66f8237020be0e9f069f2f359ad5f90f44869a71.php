<p>Name: <?php echo e(is_string($name) ? htmlspecialchars($name, ENT_QUOTES, 'UTF-8') : 'Invalid data'); ?></p>
<p>Email: <?php echo e(is_string($email) ? htmlspecialchars($email, ENT_QUOTES, 'UTF-8') : 'Invalid data'); ?></p>
<p>Project: <?php echo e(is_string($EmailEntreprise) ? htmlspecialchars($EmailEntreprise, ENT_QUOTES, 'UTF-8') : 'Invalid data'); ?></p>
<p>Message: <?php echo e(is_string($message) ? htmlspecialchars($message, ENT_QUOTES, 'UTF-8') : 'Invalid data'); ?></p>
<?php /**PATH C:\wamp64\www\webari\webpanvac\resources\views/emails/contact.blade.php ENDPATH**/ ?>